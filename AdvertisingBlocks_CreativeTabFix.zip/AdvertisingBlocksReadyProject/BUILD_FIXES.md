# Build fixes

Fixed two NeoForge/Minecraft 1.21.1 API mismatches reported by GitHub Actions:

- Use the mod event bus injected into the `@Mod` constructor instead of `FMLJavaModLoadingContext`.
- Update BlockEntity `saveAdditional` and `loadAdditional` overrides to accept `HolderLookup.Provider`.

These changes address the six compiler errors from the previous CI run. They do not guarantee the next build will pass; rerun GitHub Actions and use any new compiler output to continue fixing the project.
