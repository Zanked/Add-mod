package net.example.advertisingblocks.registry;

import net.example.advertisingblocks.AdvertisingBlocks;
import net.example.advertisingblocks.blockentity.AdvertisingPanelBlockEntity;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

public final class ModBlockEntities {
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
        DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, AdvertisingBlocks.MOD_ID);

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<AdvertisingPanelBlockEntity>> ADVERTISING_PANEL =
        BLOCK_ENTITIES.register("advertising_panel",
            () -> BlockEntityType.Builder.of(AdvertisingPanelBlockEntity::new, ModBlocks.AD_PANEL.get()).build(null));

    private ModBlockEntities() {}
}
