package net.example.advertisingblocks.block;

import net.minecraft.util.StringRepresentable;
import net.minecraft.world.level.block.state.properties.IntegerProperty;

public final class AdvertisingPanelProperties {
    public static final IntegerProperty SIZE_INDEX = IntegerProperty.create("size_index", 0, 4);
    public static final IntegerProperty ART_INDEX = IntegerProperty.create("art_index", 0, 5);

    private static final String[] SIZES = {"1x1", "2x2", "3x2", "4x3", "6x3"};
    private static final String[] ARTS = {"Кола", "Синяя газировка", "Бургер", "Кофе", "Авто", "Техника"};

    public static String sizeName(int i) { return SIZES[Math.floorMod(i, SIZES.length)]; }
    public static String artName(int i) { return ARTS[Math.floorMod(i, ARTS.length)]; }

    private AdvertisingPanelProperties() {}
}
