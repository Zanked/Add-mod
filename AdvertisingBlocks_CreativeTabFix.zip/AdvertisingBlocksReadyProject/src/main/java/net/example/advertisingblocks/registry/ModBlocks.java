package net.example.advertisingblocks.registry;

import net.example.advertisingblocks.AdvertisingBlocks;
import net.example.advertisingblocks.block.AdvertisingPanelBlock;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

public final class ModBlocks {
    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(AdvertisingBlocks.MOD_ID);

    public static final DeferredBlock<AdvertisingPanelBlock> AD_PANEL = BLOCKS.register(
        "advertising_panel",
        () -> new AdvertisingPanelBlock()
    );

    private ModBlocks() {}
}
