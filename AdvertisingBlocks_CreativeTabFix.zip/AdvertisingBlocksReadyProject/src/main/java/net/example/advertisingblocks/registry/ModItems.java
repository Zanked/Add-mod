package net.example.advertisingblocks.registry;

import net.example.advertisingblocks.AdvertisingBlocks;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;

public final class ModItems {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(AdvertisingBlocks.MOD_ID);

    public static final DeferredItem<BlockItem> AD_PANEL = ITEMS.register(
        "advertising_panel",
        () -> new BlockItem(ModBlocks.AD_PANEL.get(), new Item.Properties())
    );

    private ModItems() {}
}
