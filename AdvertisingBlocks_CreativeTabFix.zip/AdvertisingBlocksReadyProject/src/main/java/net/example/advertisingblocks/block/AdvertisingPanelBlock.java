package net.example.advertisingblocks.block;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.phys.BlockHitResult;

public class AdvertisingPanelBlock extends Block {
    private static final int[][] SIZES = {{1,1},{2,2},{3,2},{4,3},{6,3}};
    private static final String[] SIZE_NAMES = {"1x1","2x2","3x2","4x3","6x3"};

    public AdvertisingPanelBlock() {
        super(BlockBehaviour.Properties.of()
            .strength(1.0F, 3.0F)
            .sound(SoundType.METAL)
            .noOcclusion());
        registerDefaultState(stateDefinition.any()
            .setValue(AdvertisingPanelProperties.SIZE_INDEX, 0)
            .setValue(AdvertisingPanelProperties.ART_INDEX, 0));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(AdvertisingPanelProperties.SIZE_INDEX, AdvertisingPanelProperties.ART_INDEX);
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos,
                                                Player player, BlockHitResult hit) {
        if (level.isClientSide) return InteractionResult.SUCCESS;

        if (player.isShiftKeyDown()) {
            int nextArt = (state.getValue(AdvertisingPanelProperties.ART_INDEX) + 1) % 6;
            BlockState changed = state.setValue(AdvertisingPanelProperties.ART_INDEX, nextArt);
            level.setBlock(pos, changed, 3);
            player.displayClientMessage(Component.literal("Реклама: " +
                AdvertisingPanelProperties.artName(nextArt)), true);
            return InteractionResult.CONSUME;
        }

        int nextSize = (state.getValue(AdvertisingPanelProperties.SIZE_INDEX) + 1) % SIZES.length;
        BlockState configured = state.setValue(AdvertisingPanelProperties.SIZE_INDEX, nextSize);
        level.setBlock(pos, configured, 3);
        int width = SIZES[nextSize][0];
        int height = SIZES[nextSize][1];

        // MVP multiblock: build a vertical panel in the X/Y plane.
        // Blocks are placed only into air or replaceable spaces; existing blocks are preserved.
        int placed = 0;
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                BlockPos target = pos.offset(x, y, 0);
                if (target.equals(pos)) {
                    placed++;
                    continue;
                }
                if (level.getBlockState(target).isAir() || level.getBlockState(target).canBeReplaced()) {
                    level.setBlock(target, configured, 3);
                    placed++;
                }
            }
        }
        player.displayClientMessage(Component.literal(
            "Рекламный щит " + SIZE_NAMES[nextSize] + ": создано блоков " + placed +
            ". Панель строится вдоль X и вверх."), true);
        return InteractionResult.CONSUME;
    }
}
