package net.example.advertisingblocks;

import net.example.advertisingblocks.registry.ModBlocks;
import net.example.advertisingblocks.registry.ModBlockEntities;
import net.example.advertisingblocks.registry.ModItems;
import net.minecraft.world.item.CreativeModeTabs;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;

@Mod(AdvertisingBlocks.MOD_ID)
public final class AdvertisingBlocks {
    public static final String MOD_ID = "advertising_blocks";

    public AdvertisingBlocks(IEventBus modEventBus) {
        ModBlocks.BLOCKS.register(modEventBus);
        ModItems.ITEMS.register(modEventBus);
        ModBlockEntities.BLOCK_ENTITIES.register(modEventBus);

        // Explicitly register the panel in several tabs so it is easy to find.
        modEventBus.addListener(this::addCreativeTabItems);
    }

    private void addCreativeTabItems(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey().equals(CreativeModeTabs.BUILDING_BLOCKS)
                || event.getTabKey().equals(CreativeModeTabs.FUNCTIONAL_BLOCKS)
                || event.getTabKey().equals(CreativeModeTabs.DECORATIONS)) {
            event.accept(ModItems.AD_PANEL.get());
        }
    }
}
