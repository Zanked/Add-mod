package net.example.advertisingblocks;

import net.example.advertisingblocks.registry.ModBlocks;
import net.example.advertisingblocks.registry.ModBlockEntities;
import net.example.advertisingblocks.registry.ModItems;
import net.minecraft.world.item.CreativeModeTabs;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(AdvertisingBlocks.MOD_ID)
public final class AdvertisingBlocks {
    public static final String MOD_ID = "advertising_blocks";

    public AdvertisingBlocks() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModBlocks.BLOCKS.register(bus);
        ModItems.ITEMS.register(bus);
        ModBlockEntities.BLOCK_ENTITIES.register(bus);
        bus.addListener(this::addCreativeTabItems);
    }

    private void addCreativeTabItems(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey().equals(CreativeModeTabs.FUNCTIONAL_BLOCKS)) {
            event.accept(ModItems.AD_PANEL.get());
        }
    }
}
