package net.example.advertisingblocks.blockentity;

import net.example.advertisingblocks.registry.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Stores the billboard settings on the anchor panel.
 * Width/height are limited to 1..16 to avoid accidental huge structures.
 */
public class AdvertisingPanelBlockEntity extends BlockEntity {
    private int billboardWidth = 3;
    private int billboardHeight = 2;
    private String imageId = "cola_classic";

    public AdvertisingPanelBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.ADVERTISING_PANEL.get(), pos, state);
    }

    public int getBillboardWidth() { return billboardWidth; }
    public int getBillboardHeight() { return billboardHeight; }
    public String getImageId() { return imageId; }

    public void setBillboardSize(int width, int height) {
        this.billboardWidth = Math.max(1, Math.min(16, width));
        this.billboardHeight = Math.max(1, Math.min(16, height));
        setChanged();
    }

    public void setImageId(String imageId) {
        if (imageId == null || !imageId.matches("[a-z0-9_]{1,48}")) return;
        this.imageId = imageId;
        setChanged();
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.putInt("BillboardWidth", billboardWidth);
        tag.putInt("BillboardHeight", billboardHeight);
        tag.putString("ImageId", imageId);
    }

    @Override
    protected void loadAdditional(CompoundTag tag) {
        super.loadAdditional(tag);
        billboardWidth = Math.max(1, Math.min(16, tag.getInt("BillboardWidth")));
        billboardHeight = Math.max(1, Math.min(16, tag.getInt("BillboardHeight")));
        imageId = tag.contains("ImageId") ? tag.getString("ImageId") : "cola_classic";
    }
}
