# Advertising Blocks

**Minecraft Java Edition 1.21.1 · NeoForge 21.1.x · Java 21**

A work-in-progress urban advertising panel mod: beverage, food, automotive, electronics and retail-themed 64×64 textures.

## Current features
- `Advertising Panel` block and inventory item.
- Listed in the Functional Blocks creative tab.
- Crafting recipe: 6 iron ingots, 2 glass panes and 1 paper.
- Five size presets: 1×1, 2×2, 3×2, 4×3 and 6×3.
- Six selectable built-in designs in the current interaction prototype.
- 64×64 texture collection in `assets/advertising_blocks/textures/block/`.
- Seamless billboard artwork: the selected design is resized to the chosen panel aspect ratio and split into per-tile textures, so neighboring blocks show adjacent portions of one image.
- Example connected-texture resource-pack rule under `resourcepack_ctm/`.

## Finding the block in-game
The item is registered as `advertising_blocks:advertising_panel` and is added to Building Blocks, Functional Blocks, and Decorations.
If it still does not appear in the creative inventory, test in a world with cheats enabled:
```mcfunction
/give @s advertising_blocks:advertising_panel
```
If `/give` says the item does not exist, the installed JAR is likely an older build or the registry failed; check `latest.log`.

## Controls
- **Right-click** any tile to cycle the size preset; the panel is rebuilt along world X and upward.
- **Shift + right-click** any tile to cycle the design across the whole panel.
- Each tile has its own `tile_x`/`tile_y` state and uses a cropped texture segment to create a continuous image across the panel.

## Known limitations — read before using
This is a source prototype, not a verified release build.
- This update has **not yet been compiled or launched in Minecraft in this environment**; confirm the GitHub Actions build before replacing your working JAR.
- Multiblock placement remains a prototype: the panel grows along world X and upward, does not rotate to match player facing, and can be disrupted by manually breaking individual tiles.
- Artwork is mapped continuously using generated tile textures. The source artwork is stretched to match the chosen billboard aspect ratio before being divided into tiles.
- A configuration screen and custom-image import are not implemented yet.
- Continuity/CTM support is a resource-pack example. Continuity does not itself implement the billboard logic.

## Build locally
Install JDK 21 and Gradle, then run from the project directory:

Windows:
```bat
gradle build
```

Linux/macOS:
```bash
gradle build
```

The resulting mod JAR should appear in `build/libs/`. If Gradle reports an API or dependency error, fix that before treating the JAR as usable.

## GitHub
1. Create an empty repository.
2. Upload the contents of this folder (not the ZIP file itself).
3. Push to the default branch.
4. The included GitHub Actions workflow will attempt a build and upload the JAR as an artifact if it succeeds.

## Project layout
- `src/main/java/` — Java mod source
- `src/main/resources/assets/` — block models, states, language and textures
- `src/main/resources/data/` — recipe
- `resourcepack_ctm/` — example connected-texture rule
- `.github/workflows/build.yml` — CI build

## License
MIT. See `LICENSE`.
