package net.example.advertisingblocks.client;

import net.example.advertisingblocks.block.AdvertisingPanelProperties;
import net.example.advertisingblocks.network.ConfigureBillboardPayload;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.network.PacketDistributor;

public final class AdvertisingPanelScreen extends Screen {
    private static final String[] ART_NAMES = {"Кола", "Синяя", "Бургер", "Кофе", "Авто", "Техника"};
    private static final String[] SIZE_NAMES = {"1×1", "2×2", "3×2", "4×3", "6×3"};
    private final BlockPos pos;
    private int selectedSize;
    private int selectedArt;

    public AdvertisingPanelScreen(BlockPos pos, int sizeIndex, int artIndex) {
        super(Component.literal("Настройка рекламного щита"));
        this.pos = pos;
        this.selectedSize = Math.max(0, Math.min(4, sizeIndex));
        this.selectedArt = Math.max(0, Math.min(5, artIndex));
    }

    @Override
    protected void init() {
        int left = this.width / 2 - 130;
        int top = this.height / 2 - 82;
        for (int i = 0; i < SIZE_NAMES.length; i++) {
            final int index = i;
            addRenderableWidget(Button.builder(Component.literal((selectedSize == i ? "✓ " : "") + SIZE_NAMES[i]),
                button -> { selectedSize = index; rebuildWidgets(); }).bounds(left + i * 52, top + 30, 48, 20).build());
        }
        for (int i = 0; i < ART_NAMES.length; i++) {
            final int index = i;
            int col = i % 3;
            int row = i / 3;
            addRenderableWidget(Button.builder(Component.literal((selectedArt == i ? "✓ " : "") + ART_NAMES[i]),
                button -> { selectedArt = index; rebuildWidgets(); }).bounds(left + col * 88, top + 72 + row * 25, 82, 20).build());
        }
        addRenderableWidget(Button.builder(Component.literal("Применить"), button -> {
            PacketDistributor.sendToServer(new ConfigureBillboardPayload(pos, selectedSize, selectedArt));
            onClose();
        }).bounds(left + 4, top + 132, 124, 22).build());
        addRenderableWidget(Button.builder(Component.literal("Отмена"), button -> onClose())
            .bounds(left + 138, top + 132, 124, 22).build());
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        renderBackground(graphics, mouseX, mouseY, partialTick);
        super.render(graphics, mouseX, mouseY, partialTick);
        int left = this.width / 2 - 130;
        int top = this.height / 2 - 82;
        graphics.drawCenteredString(font, title, this.width / 2, top + 5, 0xFFFFFF);
        graphics.drawString(font, Component.literal("Размер щита:"), left, top + 19, 0xD0D0D0);
        graphics.drawString(font, Component.literal("Рекламный дизайн:"), left, top + 60, 0xD0D0D0);
        graphics.drawString(font, Component.literal("Выбрано: " + AdvertisingPanelProperties.sizeName(selectedSize)
            + " / " + AdvertisingPanelProperties.artName(selectedArt)), left, top + 119, 0xAAAAAA);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
