package net.example.advertisingblocks.client;

import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;

public final class ClientScreens {
    private ClientScreens() {}

    public static void openBillboardScreen(BlockPos pos, int sizeIndex, int artIndex) {
        Minecraft.getInstance().setScreen(new AdvertisingPanelScreen(pos, sizeIndex, artIndex));
    }
}
