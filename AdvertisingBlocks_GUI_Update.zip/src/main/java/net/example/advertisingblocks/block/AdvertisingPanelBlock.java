
package net.example.advertisingblocks.block;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.phys.BlockHitResult;

public class AdvertisingPanelBlock extends Block {
    private static final int[][] SIZES = {
        {1, 1},
        {2, 2},
        {3, 2},
        {4, 3},
        {6, 3}
    };

    public AdvertisingPanelBlock() {
        super(BlockBehaviour.Properties.of()
            .strength(1.0F, 3.0F)
            .sound(SoundType.METAL)
            .noOcclusion());

        registerDefaultState(stateDefinition.any()
            .setValue(AdvertisingPanelProperties.FACING, Direction.NORTH)
            .setValue(AdvertisingPanelProperties.SIZE_INDEX, 0)
            .setValue(AdvertisingPanelProperties.ART_INDEX, 0)
            .setValue(AdvertisingPanelProperties.TILE_X, 0)
            .setValue(AdvertisingPanelProperties.TILE_Y, 0));
    }

    @Override
    protected void createBlockStateDefinition(
            StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(
            AdvertisingPanelProperties.FACING,
            AdvertisingPanelProperties.SIZE_INDEX,
            AdvertisingPanelProperties.ART_INDEX,
            AdvertisingPanelProperties.TILE_X,
            AdvertisingPanelProperties.TILE_Y
        );
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        return defaultBlockState().setValue(
            AdvertisingPanelProperties.FACING,
            context.getHorizontalDirection().getOpposite()
        );
    }

    private static BlockPos tilePos(
            BlockPos anchor, int x, int y, Direction facing) {
        Direction widthDirection = facing.getClockWise();
        return anchor.relative(widthDirection, x).above(y);
    }

    private BlockPos getAnchor(BlockPos pos, BlockState state) {
        int tileX = state.getValue(AdvertisingPanelProperties.TILE_X);
        int tileY = state.getValue(AdvertisingPanelProperties.TILE_Y);

        return tilePos(
            pos,
            -tileX,
            -tileY,
            state.getValue(AdvertisingPanelProperties.FACING)
        );
    }

    private boolean belongsToPanel(
            BlockState state, int sizeIndex, Direction facing) {
        return state.getBlock() == this
            && state.getValue(AdvertisingPanelProperties.SIZE_INDEX) == sizeIndex
            && state.getValue(AdvertisingPanelProperties.FACING) == facing;
    }

    private boolean belongsToThisPanel(
            BlockPos pos,
            BlockState state,
            int sizeIndex,
            Direction facing,
            BlockPos anchor) {
        return belongsToPanel(state, sizeIndex, facing)
            && getAnchor(pos, state).equals(anchor);
    }

    @Override
    protected InteractionResult useWithoutItem(
            BlockState state,
            Level level,
            BlockPos pos,
            Player player,
            BlockHitResult hit) {

        if (level.isClientSide) {
            int sizeIndex = state.getValue(
                AdvertisingPanelProperties.SIZE_INDEX);
            int artIndex = state.getValue(
                AdvertisingPanelProperties.ART_INDEX);

            net.example.advertisingblocks.client.ClientScreens
                .openBillboardScreen(pos, sizeIndex, artIndex);
        }

        return InteractionResult.SUCCESS;
    }

    /** Applies settings to the whole panel after validating the new footprint. */
    public void applyConfiguration(
            Level level,
            BlockPos clickedPos,
            Player player,
            int nextSize,
            int nextArt) {

        if (level.isClientSide
                || nextSize < 0
                || nextSize >= SIZES.length
                || nextArt < 0
                || nextArt > 5) {
            return;
        }

        BlockState clickedState = level.getBlockState(clickedPos);

        if (!belongsToPanel(
                clickedState,
                clickedState.getValue(AdvertisingPanelProperties.SIZE_INDEX),
                clickedState.getValue(AdvertisingPanelProperties.FACING))) {
            return;
        }

        int oldSize = clickedState.getValue(
            AdvertisingPanelProperties.SIZE_INDEX);
        Direction facing = clickedState.getValue(
            AdvertisingPanelProperties.FACING);
        BlockPos anchor = getAnchor(clickedPos, clickedState);

        int oldWidth = SIZES[oldSize][0];
        int oldHeight = SIZES[oldSize][1];
        int newWidth = SIZES[nextSize][0];
        int newHeight = SIZES[nextSize][1];

        // Do not overwrite unrelated blocks.
        for (int y = 0; y < newHeight; y++) {
            for (int x = 0; x < newWidth; x++) {
                BlockPos target = tilePos(anchor, x, y, facing);
                BlockState existing = level.getBlockState(target);

                boolean oldTile = belongsToThisPanel(
                    target, existing, oldSize, facing, anchor);

                if (!existing.isAir() && !oldTile) {
                    if (player != null) {
                        player.displayClientMessage(
                            Component.literal(
                                "Недостаточно места для щита "
                                    + AdvertisingPanelProperties.sizeName(nextSize)
                                    + ". Освободи место и попробуй снова."
                            ),
                            true
                        );
                    }
                    return;
                }
            }
        }

        // Remove only tiles belonging to this panel.
        for (int y = 0; y < oldHeight; y++) {
            for (int x = 0; x < oldWidth; x++) {
                BlockPos oldPos = tilePos(anchor, x, y, facing);
                BlockState old = level.getBlockState(oldPos);

                if (belongsToThisPanel(
                        oldPos, old, oldSize, facing, anchor)) {
                    level.removeBlock(oldPos, false);
                }
            }
        }

        // Build the panel using the new size and artwork.
        for (int y = 0; y < newHeight; y++) {
            for (int x = 0; x < newWidth; x++) {
                BlockPos target = tilePos(anchor, x, y, facing);

                BlockState tile = defaultBlockState()
                    .setValue(AdvertisingPanelProperties.FACING, facing)
                    .setValue(AdvertisingPanelProperties.SIZE_INDEX, nextSize)
                    .setValue(AdvertisingPanelProperties.ART_INDEX, nextArt)
                    .setValue(AdvertisingPanelProperties.TILE_X, x)
                    .setValue(AdvertisingPanelProperties.TILE_Y, y);

                level.setBlock(target, tile, 3);
            }
        }

        if (player != null) {
            player.displayClientMessage(
                Component.literal(
                    "Щит применён: "
                        + AdvertisingPanelProperties.sizeName(nextSize)
                        + " / "
                        + AdvertisingPanelProperties.artName(nextArt)
                ),
                true
            );
        }
    }
}
