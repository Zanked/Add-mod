package net.example.advertisingblocks.network;

import net.example.advertisingblocks.AdvertisingBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

public record ConfigureBillboardPayload(BlockPos pos, int sizeIndex, int artIndex) implements CustomPacketPayload {
    public static final Type<ConfigureBillboardPayload> TYPE = new Type<>(
        ResourceLocation.fromNamespaceAndPath(AdvertisingBlocks.MOD_ID, "configure_billboard"));

    public static final StreamCodec<RegistryFriendlyByteBuf, ConfigureBillboardPayload> STREAM_CODEC =
        StreamCodec.composite(
            BlockPos.STREAM_CODEC, ConfigureBillboardPayload::pos,
            ByteBufCodecs.VAR_INT, ConfigureBillboardPayload::sizeIndex,
            ByteBufCodecs.VAR_INT, ConfigureBillboardPayload::artIndex,
            ConfigureBillboardPayload::new
        );

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
