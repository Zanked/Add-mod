package net.example.advertisingblocks.network;

import net.example.advertisingblocks.block.AdvertisingPanelBlock;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.network.handling.IPayloadContext;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

public final class ModNetworking {
    private ModNetworking() {}

    public static void register(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar("1");
        registrar.playToServer(ConfigureBillboardPayload.TYPE, ConfigureBillboardPayload.STREAM_CODEC,
            ModNetworking::handleConfigure);
    }

    private static void handleConfigure(ConfigureBillboardPayload payload, IPayloadContext context) {
        if (!(context.player() instanceof ServerPlayer player)) return;
        Level level = player.level();
        if (!level.hasChunkAt(payload.pos()) || player.distanceToSqr(
                payload.pos().getX() + 0.5, payload.pos().getY() + 0.5, payload.pos().getZ() + 0.5) > 64.0) return;
        BlockState state = level.getBlockState(payload.pos());
        if (!(state.getBlock() instanceof AdvertisingPanelBlock panel)) return;
        if (payload.sizeIndex() < 0 || payload.sizeIndex() > 4 || payload.artIndex() < 0 || payload.artIndex() > 5) return;
        panel.applyConfiguration(level, payload.pos(), player, payload.sizeIndex(), payload.artIndex());
    }
}
